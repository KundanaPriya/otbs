﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(OTBS.Startup))]
namespace OTBS
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
