﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using OTBS.Models;

namespace OTBS.Controllers
{
    public class CustomerController : Controller
    {
        Training_20March_CloudChennaiEntities db = new Training_20March_CloudChennaiEntities();
        //Customer Login

        [HttpGet]
        public ActionResult CustomerLogin()
        {
            return View();
        }

        [HttpPost]
        public ActionResult CustomerLogin(CustomerTable t)
        {
            CustomerTable ad = db.CustomerTables.Where(x => x.EmailID == t.EmailID && x.password == t.password).SingleOrDefault();
            if (ad != null)
            {

                Session["CustomerID"] = ad.EmailID.ToString();
                return RedirectToAction("CustomerRoles");
            }
            else
            {
                ViewBag.error = "Invalid username or password";
            }
            return View();
        }

        public ActionResult CustomerRoles()
        {
            return View();
        }

        [HttpGet]
        public ActionResult Feedback()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Feedback(Feedback feedbacktable)
        {
            db.Feedbacks.Add(feedbacktable);
            db.SaveChanges();
            return Redirect("/Home/Index");
        }


        [HttpGet]
        public ActionResult Booking()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Booking(Booking Bookingtable)
        {
            db.Bookings.Add(Bookingtable);
            db.SaveChanges();
            return Redirect("/Home/Index");
        }

        public ActionResult Checkdrivehistory()
        {
            List<EmployeeTable> ls = db.EmployeeTables.ToList<EmployeeTable>();
            return View(ls);
        }
    }
}