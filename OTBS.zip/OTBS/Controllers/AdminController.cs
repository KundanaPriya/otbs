﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using OTBS.Models;
namespace OTBS.Controllers
{
    public class AdminController : Controller
    {
        Training_20March_CloudChennaiEntities db = new Training_20March_CloudChennaiEntities();


        public ActionResult AdminLogin()
        {
            return View();
        }

        [HttpPost]
        public ActionResult AdminLogin(AdminLogin login)
        {
            if (ModelState.IsValid)
            {

                var user = (from userlist in db.AdminLogins
                            where userlist.UserName == login.UserName && userlist.password == login.password
                            select new
                            {
                                userlist.UserName

                            }).ToList();


                if (user.FirstOrDefault() != null)
                {

                    Session["UserName"] = user.FirstOrDefault().UserName;

                    return Redirect("/Admin/AdminRoles");
                }
                else
                {
                    ModelState.AddModelError("", "Invalid login credentials.");
                }
            }
            return View(login);
        }

        public ActionResult AdminRoles()
        {
            return View();
        }

        public ActionResult EmployeeRoster()
        {
            return View();
        }


        //register   employees

        [HttpGet]
        public ActionResult ResigterEmployee()
        {
            return View();
        }
        [HttpPost]
        public ActionResult ResigterEmployee(EmployeeTable employeeTable)
        {
            db.EmployeeTables.Add(employeeTable);
            db.SaveChanges();
            return Redirect("/Home/Index");
        }


        public ActionResult DisplayFeedback()
        {
            List<Feedback> ls = db.Feedbacks.ToList<Feedback>();
            return View(ls);
        }

        public ActionResult Manageallsystem()
        {
            return View();
        }
    }
}