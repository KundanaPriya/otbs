﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using OTBS.Models;

namespace OTBS.Controllers
{
    public class EmployeeController : Controller
    {
        Training_20March_CloudChennaiEntities db = new Training_20March_CloudChennaiEntities();
        //Employee Login

        [HttpGet]
        public ActionResult EmployeeLogin()
        {
            return View();
        }

        [HttpPost]
        public ActionResult EmployeeLogin(EmployeeTable t)
        {
            EmployeeTable ad = db.EmployeeTables.Where(x => x.EmailID == t.EmailID && x.password == t.password).SingleOrDefault();
            if (ad != null)
            {

                Session["CustomerID"] = ad.EmailID.ToString();

                return RedirectToAction("EmployeeRoles");
            }
            else
            {
                ViewBag.error = "Invalid username or password";
            }
            return View();
        }



        public ActionResult EmployeeRoles()
        {

            return View();
        }



        public ActionResult CheckEmployeeRoster()
        {
            List<EmployeeRoster> ls = db.EmployeeRosters.ToList<EmployeeRoster>();
            return View(ls);
        }

        public ActionResult CheckBooking()
        {
            List<Booking> ls = db.Bookings.ToList<Booking>();
            return View(ls);
        }
    }
}